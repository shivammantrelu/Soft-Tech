function getBotResponse(input) {
    //rock paper scissors
    if (input == "rock") {
        return "paper";
    } else if (input == "paper") {
        return "scissors";
    } else if (input == "scissors") {
        return "rock";
    }

    // Simple responses
     if (input == "Hi"){
        return "Welcome to SOFT TECH.We are happy to help you"
     }
    if (input == "My Self Shivam") {
        return "Hey Shivam.. which course u want to enroll in..?";
    } else if (input == "I want to ask about courses") {
        return "Thank u we would connect u in few minutes ..And please enter course name";
    } else if (input == "Full Stack Web Development") {
        return "Duration: 6 Month or 7, Fees: 5000 &#8377, and please Text your whatsapp no. To send further details";
    }else if (input == "9518705566") {
        return "Thank you Shivam we will connect with u shortly";
    }else if (input == "My Self Amruta") {
        return "Hey Amruta.. WHich course u want to enroll in..?";
    }else if (input == "Devops") {
        return "Duration: 45 Days to 60 , Fees: 8000 &#8377, and please Text your whatsapp no. To send further details";
    }else if (input == "9049424501") {
        return "Thank you Amruta we will connect with u shortly";
    }else if (input == "ok") {
        return "Any other help";
    }else if (input == "no") {
        return "Enjoy ur day";
    }else if (input == "My SelfSahil") {
        return "Hey Sahil..which course u want to enroll..?";
    }else if (input == "Data Science") {
        return "Duration: 7 Month, Fees: 20000 &#8377, And please Text your whatsapp no. to send further details ";
    }else if (input =="8446347962"){
        return"Thank you Sahil we will connect you u shortly.."
    }else if (input =="Good Bye"){
        return"Thank you please visit again"
    }
else {
        return "Try asking something else!";
    }
}